<?php
require('koneksi.php');

$response = array();
if($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    $nama = $_POST["nama"];
    $npm = $_POST["npm"];
    $nilai = $_POST["nilai"];

    $perintah = "INSERT INTO tbl_project (nama, npm, nilai) VALUES('$nama', '$npm', '$nilai')"; // hapus tanda kutip tunggal yang tertinggal pada akhir string
    $eksekusi = mysqli_query($konek, $perintah);
    $cek = mysqli_affected_rows($konek);

    if($cek > 0) 
    {
        $response["kode"] = 1;
        $response["pesan"] = "Simpan Data Berhasil";
    }
    else 
    {
        $response["kode"] = 0;
        $response["pesan"] = "Gagal Menyimpan Data";
        $response["error"] = mysqli_error($konek);
    }
}
else 
{
    $response["kode"] = 0;
    $response["pesan"] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($konek);