<?php
$host = "localhost";
$user = "id18509641_projectdata";
$pass = "D!u_~12kZTjGS#a+";
$db = "id18509641_data";

$konek = mysqli_connect($host, $user, $pass, $db) or die("Database MYSQL Tidak Terhubung");
